package com.java;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class Assest1 {
  @RequestMapping("/hello")

  public String display(@RequestParam("ename") String name,@RequestParam("pass") String pass,@RequestParam("email") String email,@RequestParam("eaddress") String addr,
		  @RequestParam("Designation") String designation,@RequestParam("salary") String Salary, Model m) throws  Exception

  {

    if(pass.equals("admin"))

    {

      String msg="Hello "+ name+" registration is successfull
      String name="e_Name :-"+ename;
      String email="e_Email :- "+Email;
      String address="e_Address :- "+eaddress;
      String designation="e_Designation :- "+Designation;
      String Salary="e_Salary :- "+salary;

      

      m.addAttribute("information", msg);
      m.addAttribute("information1",name );
      m.addAttribute("information3",email);
      m.addAttribute("information4",address);
      m.addAttribute("information5",designation);
      m.addAttribute("information6",Salary);
      
            return "viewpage";

    }

    else

    {

      String msg="Sorry "+ name+". You are not existing employee plz enter correct password provided by company";

      m.addAttribute("information", msg);

      return "errorpage";

    }

  }

}


package com.mcnz.jpa.examples;

import java.util.*;
import javax.persistence.*;

public class JpaCrudExample {

  public static void main(String[] args) throws Exception {
    JpaCrudExample.createRecord();
    JpaCrudExample.retrieveRecord();
    JpaCrudExample.updateRecord();
    JpaCrudExample.deleteRecord();
  }

  public static void createRecord() { }
  public static void retrieveRecord() { }
  public static void updateRecord() { }
  public static void deleteRecord() { }

}
